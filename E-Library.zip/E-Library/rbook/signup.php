

<?php include("header.php");?>
<?php
 $id = $_GET['id'];
  $type = $_GET['type'];
  include ("database/db.php"); 
    if (isset($_POST['username']) && isset($_POST['email'])){
    if (isset($_POST['username'])){
    $username = stripslashes($_REQUEST['username']);
    $username = mysqli_real_escape_string($con,$username);
    $email = stripslashes($_REQUEST['email']); 
    $email = mysqli_real_escape_string($con,$email); 
    $password = stripslashes($_REQUEST['password']); 
    $password = mysqli_real_escape_string($con,$password); 
    $password1 = stripslashes($_REQUEST['password1']);
    $password1 = mysqli_real_escape_string($con,$password1);
    if ($password != $password1) {
       $fmsg ="Passwords dont match!";
        }else{

 $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
        if($rows!=0){
            $fmsg ="Email already exists!";
           }else{
             $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
        if($rows!=0){
            $fmsg ="Username already exists!";
           }else{
            $query = "INSERT INTO users (username, email, password) VALUES('$username', '$email', '$password')";
     $result = mysqli_query($con,$query);
      if($result){
         $URL="login.php?id=$id&type=$type";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
}else{
           $fmsg ="Failed to register!";
        }  }}}}}?>
          

           
    
  
         
         
       
          
        
<div id="main" class="shell">
  <div class="login">
      <div>
        <h1> Sign Up</h1><br>
        <?php if(isset($smsg)){ ?><br><div class="success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>  
<?php if(isset($fmsg)){ ?><br><div class="danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>

          <form action="" method="post">
          <input type="text" name="username" required placeholder="Username"/>
          <input type="email" name="email" required placeholder="Email address"/>
          <input type="password" name="password" required placeholder="Password"/>
        
          <input type="password" name="password1" required placeholder="Retype password"/>
        
          <input type="submit" name="signup-button" value="Sign Up"/>
          </form>
        
        </div>
       
        
    </div>
</div>

<?php include("footer.php");?>
