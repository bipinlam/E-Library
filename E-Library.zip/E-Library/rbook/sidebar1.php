<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					<h4>My menu</h4>
					<ul><li><a href="home.php">Home</a></li>
						<li><a href="rented.php">Rented books</a></li>
						<li><a href="bought.php">Bought books</a></li>
						</ul>
				</li>
				</ul>
		</div>
		<!-- End Sidebar -->