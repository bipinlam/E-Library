<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					<h4>Categories</h4>
					<ul>
						<li><a href="#">Science fiction</a></li>
						<li><a href="#">Satire</a></li>
						<li><a href="#">Drama</a></li>
						<li><a href="#">Action and Adventure</a></li>
						<li><a href="#">Romance</a></li>
						<li><a href="#">Mystery</a></li>
						<li><a href="#">Horror</a></li>
					</ul>
				</li>
				<li>
					<h4>Authors</h4>
					<ul>
						<li><a href="#">Stephen King</a></li>
						<li><a href="#">J.K. Rowlin</a></li>
						<li><a href="#">James Patterson</a></li>
						<li><a href="#">David Baldacci</a></li>
						<li><a href="#">Ernest Hemingway</a></li>
						<li><a href="#">J.R.R. Tolkien</a></li>
						<li><a href="#">William Shakespeare</a></li>
						<li><a href="#">Jane Austen</a></li>
						<li><a href="#">Agatha Christe</a></li>
						<li><a href="#">MIchael Crichton</a></li>
						<li><a href="#">Leo Tolstoy</a></li>
						<li><a href="#">Lee Child</a></li>
					</ul>
				</li>
			</ul>
		</div>
		<!-- End Sidebar -->