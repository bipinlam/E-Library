<?php
   session_start();
   //$id = $_GET['id'];
   if($_SESSION['username']){ 
   }
   else{
 // Print '<script>alert("You need to be logged in first!");</script>';
           $URL="login.php?id=0";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
   }
   $username = $_SESSION['username']; 

   ?>
<?php include("header1.php");?>
<div id="main" class="shell">
	<?php include("sidebar.php");?>
	<div id="content">
		<div class="products">
		<?php include 'categories.php'; ?>
	</div>
		</div>	<div class="cl">&nbsp;</div>
	
</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>

