<?php include("header.php");?>
<?php include("slider.php");?>

<div id="main" class="shell">
	<?php include("sidebar.php");?>
		<div id="content">		
	<?php include 'categories.php'; ?>    
  		</div>
			<div class="cl">&nbsp;</div>
	<?php include("bestsellers.php");?>
</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>

