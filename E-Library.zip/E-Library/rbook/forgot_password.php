<?php include("header.php");?>

<?php
 $id = $_GET['id'];
 $type = $_GET['type'];
include ("database/db.php"); 
  session_start();
   if (isset($_POST['email']) && isset($_POST['username'])){
    if (isset($_POST['email'])){
     $username = stripslashes($_REQUEST['username']); 
    $username = mysqli_real_escape_string($con,$username); 
    $email = stripslashes($_REQUEST['email']);
    $email = mysqli_real_escape_string($con,$email);
$username = "RANDOM";

   $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
        if($rows==1){

 $smsg ="Your password reset link has been mailed to you. Kindly check your email address. <br>$email";

 }else  {
         $fmsg ="Error! Your email address was not found in the database.";
        }

       
    }}?>
<div id="main" class="shell">

     <div class="login">
        <h1>Password recovery panel</h1><hr>
<?php if(isset($smsg)){ ?><br><div class="success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>  
<?php if(isset($fmsg)){ ?><br><div class="danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>

        <form action="" method="post">
            <br>
            <input type="hidden" name="username" value="_RANDOM">
            <input type="email" name="email" placeholder="Email address" required>
            <input type="submit" value="Reset"><br>
         </form>
        
</div>
            
        
    
</div>

</body>
</html>>

 