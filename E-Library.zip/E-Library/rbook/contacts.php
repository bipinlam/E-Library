<?php include("header.php");?>
<div id="main" class="shell">
  <?php include("sidebar.php");?>
  <div id="content">
    <div class="products">
    	<h3>Our contacts</h3>
 <h4>Phone number: +0405515599</h4><br>
 <h4>Email address: info@ebook.org</h4><br>
 <h4>Physical address: 454 kent street</h4>
  </div>
    </div>  <div class="cl">&nbsp;</div>
  
</div>
  <div class="cl">&nbsp;</div>

<?php include("footer.php");?>
