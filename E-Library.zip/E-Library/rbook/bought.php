<?php
error_reporting(1);
   session_start();
   //$id = $_GET['id'];
   if($_SESSION['username']){ 
   }
   else{
 // Print '<script>alert("You need to be logged in first!");</script>';
           $URL="login.php?id=0&type=0";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
   }
   $username = $_SESSION['username']; 

   ?>
<?php include("header1.php");?>
<div id="main" class="shell">
	<?php include("sidebar.php");?>
	<div id="content">
		<h3>My books repository</h3>
		<div class="products">
		<ul>
	
	<?php $result = mysqli_query($con,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
      while($row = mysqli_fetch_array($result)) {
      	$usersid = $row['id'];
      }
      	$result = mysqli_query($con,"SELECT * FROM buy WHERE users_id='$usersid'");
      while($row = mysqli_fetch_array($result)) {
      	$bookid = $row['books_id'];
      	//$expiry = $row['end_date'];
      	$created = $row['created'];
      	$res = mysqli_query($con,"SELECT * FROM books WHERE id='$bookid'");
      while($row = mysqli_fetch_array($res)) {  ?>

			<li>
						<div class="product">
						<p class="info">
	
								<span class="holder">
									<img src="css/images/<?php echo $row['pic'];?>" alt="" />
									<span class="book-name"><?php echo $row['name'];?></span>
									<span class="author">by <?php echo $row['author'];?></span>
									<span class="description"><?php echo $row['description'];?></span>
								</span>
								<span class="holder">
									<span class="book-name">Date bought: <?php echo $created;?> </span>
									<span class="author">
							<a href="css/images/<?php echo $row['book'];?>" target="_blank"><button class="read twitter">Read</button></a>
										
									</span>
									
								</span>
						</p>
					</div>
			</li>
  		
  		<?php } } mysqli_close($con); ?>
  		</ul></div>
		</div>	<div class="cl">&nbsp;</div>
	
</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>

