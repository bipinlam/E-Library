<?php
   session_start();
   $id = $_GET['id'];
   $type = $_GET['type'];
   if($_SESSION['username']){ 
   }
   else{
 // Print '<script>alert("You need to be logged in first!");</script>';
           $URL="login.php?id=$id&type=$type";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
   }
   $username = $_SESSION['username']; 

   ?>
<?php
 $id = $_GET['id'];
  include ("database/db.php"); 
   
    if (isset($_POST['users_id']) && isset($_POST['books_id'])){
    if (isset($_POST['users_id'])){
    $users_id = stripslashes($_REQUEST['users_id']);
    $users_id = mysqli_real_escape_string($con,$users_id);
    $books_id = stripslashes($_REQUEST['books_id']); 
    $books_id = mysqli_real_escape_string($con,$books_id); 
    $credit_card = stripslashes($_REQUEST['credit_card']); 
    $credit_card = mysqli_real_escape_string($con,$credit_card); 
    $created = date('y-m-d');
	//$end_date = date('y-m-d',strtotime("+1 days"));
 
     $query = "INSERT INTO buy (users_id, books_id, created, credit_card) VALUES('$users_id', '$books_id', '$created', '$credit_card')";
     $result = mysqli_query($con,$query);
      if($result){
         $URL="confirm-buy.php?id=$id&type=buy";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
}else{
           $fmsg ="Failed to rent book!";
        }  }}?>
          


<?php include("header1.php");?>
<div id="main" class="shell">
	<?php include("sidebar.php");?>
	<?php $result = mysqli_query($con,"SELECT * FROM books WHERE id='$id'");
      while($row = mysqli_fetch_array($result)) {
        $price = $row['price'];
        ?>
		<div id="content">
		<h3>Buy a book module</h3>		
	<span class="holder">
		<img src="css/images/<?php echo $row['pic'];?>" alt="" style="min-height: 300px;"/><br>
		<h4><?php echo $row['name'];?> <br>
		by <?php echo $row['author'];?></h4><br>
		<span class="description"><?php echo $row['description'];?></span><br>
		<h4>This book costs <b>$<?php echo $row['price'];?></b>. To purchase, click the button below</h4><br>
	</span>
<div>
<form action="" method="post">
<input type="hidden" name="books_id" value="<?php echo $row['id'];?>">
<?php } $result = mysqli_query($con,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
      while($row = mysqli_fetch_array($result)) {?>
<input type="hidden" name="users_id" value="<?php echo $row['id'];?>">
<input type="text" name="price" value="Book price: $<?php echo $price;?>" readonly><br>
<input type="hidden" name="credit_card">
<input type="submit" class="social facebook" value="Proceed buy">
</form>
	
</div>
  		</div>
  		 <?php } mysqli_close($con); ?>
			<div class="cl">&nbsp;</div>
	
</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>

