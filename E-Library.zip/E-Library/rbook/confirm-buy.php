<?php
   session_start();
   $id = $_GET['id'];
   $type = $_GET['type'];
   if($_SESSION['username']){ 
   }
   else{
 // Print '<script>alert("You need to be logged in first!");</script>';
           $URL="login.php?id=$id&type=$type";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
   }
   $username = $_SESSION['username']; 

   ?>
<?php
 $id = $_GET['id'];
  include ("database/db.php"); 
   
    if (isset($_POST['id']) && isset($_POST['credit_card'])){
    if (isset($_POST['id'])){
    $id = stripslashes($_REQUEST['id']);
    $id = mysqli_real_escape_string($con,$id);
    $credit_card = stripslashes($_REQUEST['credit_card']); 
    $credit_card = mysqli_real_escape_string($con,$credit_card); 
   	  
  $query = "UPDATE buy SET credit_card = '$credit_card' WHERE id='$id'";
     $result = mysqli_query($con,$query);
      if($result){
        Print '<script>alert("Your book purchase order has been approved! Congratulations!");</script>';
         $URL="bought.php";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
}else{
           $fmsg ="Failed to buy book!";
        }  }}?>
          


<?php include("header1.php");?>
<div id="main" class="shell">
	<?php include("sidebar.php");?>
	
		<div id="content">
		<h3>Make Payments</h3>		
	
		
		<?php $result = mysqli_query($con,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
      while($row = mysqli_fetch_array($result)) {
$users_id = $row['id'];
     }  ?>

<?php $result = mysqli_query($con,"SELECT * FROM buy WHERE users_id='$users_id'");
      while($row = mysqli_fetch_array($result)) {
$booksid = $row['books_id'];
     }  ?>


<?php $result = mysqli_query($con,"SELECT * FROM books WHERE id='$booksid'");
      while($row = mysqli_fetch_array($result)) {
$bookname = $row['name'];
$bookauthor = $row['author'];
$price = $row['price'];
     }  ?>
<div>
<form action="" method="post">
  <input type="hidden" name="books_id" value="<?php echo $row['id'];?>">
  <link rel="stylesheet" type="text/css" href="js/jquery.datetimepicker.css"/>

<?php 
$result = mysqli_query($con,"SELECT * FROM buy WHERE users_id='$users_id' ORDER BY id DESC LIMIT 1");
      while($row = mysqli_fetch_array($result)) { ?>

           
   <h4>You are about to buy a book <b><?php echo $bookname;?></b> authored by <b><?php echo $bookauthor;?></b></h4><br>
    <input type="hidden" name="id" value="<?php echo $row['id'];?>">
       <input type="text" name="price" value="Expected to pay $<?php echo $price;?>.00" readonly>


    <input type="text" name="credit_card" placeholder="Enter valid credit card number" required >
    

<?php } $result = mysqli_query($con,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
      while($row = mysqli_fetch_array($result)) {?>
<input type="hidden" name="users_id" value="<?php echo $row['id'];?>">
<input type="submit" class="social facebook" value="Complete">
</form>
	
</div>
  		</div>
  		 <?php } mysqli_close($con); ?>
			<div class="cl">&nbsp;</div>
	
</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>
  <script src="js/jquery.js"></script>
        <script src="js/jquery.datetimepicker.full.js"></script>

        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';

                jQuery('#filter-date, #search-from-date, #search-to-date').datetimepicker();
            });
        </script>
