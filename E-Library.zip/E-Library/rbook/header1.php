<?php include("database/db.php");?>
<!DOCTYPE html>

<html>
<head>
	<title>E-BOOK Online Library</title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.jcarousel.min.js"></script>
	<link rel="stylesheet" type="text/css" href="stylelogin.css">
	<link rel="stylesheet" type="text/css" href="signup.css">

	<!--[if IE 6]>
		<script type="text/javascript" src="js/png-fix.js"></script>
	<![endif]-->
	<script type="text/javascript" src="js/functions.js"></script>
</head>
<body>
	<!-- Header -->
	<div id="header" class="shell">

		<div id="logo"><h1><a href="#">Aussiebook</a></h1><span><a href="#">Trusted online e-book service</a></span></div>
		<!-- Navigation -->
		<div id="navigation">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="rented.php">Rented books</a></li>
				<li><a href="bought.php">Bought books</a></li>
				<li><a href="logout.php">Logout</a></li>
				
			</ul>
		</div>
		<!-- End Navigation -->
		<div class="cl">&nbsp;</div>
		<!-- Login-details -->
		<div id="login-details">
			<p>Welcome, <a href="#" id="user"><?php echo $_SESSION['username']; ?></a> .</p><p><a href="#" class="cart" ><img src="css/images/cart-icon.png" alt=""></a> 
			
		</div>
		<!-- End Login-details -->
	</div>
	<!-- End Header -->