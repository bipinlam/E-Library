	<!-- Slider -->
	<div id="slider">
		<div class="shell">
			<ul>
				<li>
					<div class="image">
						<img src="css/images/books.png" alt="" />
					</div>
					<div class="details">
						<h2>Economic</h2>
						<h3>Special Offers</h3>
						<p class="title">Anyone who stops learning is old, whether at twenty or eighty. Anyone who keeps learning stays young. The greatest thing in life is to keep your mind young.</p>
						<p class="description">OPTIMIZED FOR ALL AGE</p>
						<a href="#" class="read-more-btn">Read More</a>
					</div>
				</li>
				<li>
					<div class="image">
						<img src="css/images/s1.png" alt="" />
					</div>
					<div class="details">
						<h2>Mega Giant</h2>
						<h3>Special Offers</h3>
						<p class="title">Anyone who stops learning is old, whether at twenty or eighty. Anyone who keeps learning stays young. The greatest thing in life is to keep your mind young.</p>
						<p class="description">OPTIMIZED FOR ALL AGE</p>
						<a href="#" class="read-more-btn">Read More</a>
					</div>
				</li>
				<li>
					<div class="image">
						<img src="css/images/s2.png" alt="" />
					</div>
					<div class="details">
						<h2>Collection</h2>
						<h3>Special Offers</h3>
						<p class="title">Anyone who stops learning is old, whether at twenty or eighty. Anyone who keeps learning stays young. The greatest thing in life is to keep your mind young.</p>
						<p class="description">OPTIMIZED FOR ALL AGE</p>
						<a href="#" class="read-more-btn">Read More</a>
					</div>
				</li>
				<li>
					<div class="image">
						<img src="css/images/s3.png" alt="" />
					</div>
					<div class="details">
						<h2>Horror</h2>
						<h3>Special Offers</h3>
						<p class="title">Anyone who stops learning is old, whether at twenty or eighty. Anyone who keeps learning stays young. The greatest thing in life is to keep your mind young.</p>
						<p class="description">OPTIMIZED FOR ALL AGE</p>
						<a href="#" class="read-more-btn">Read More</a>
					</div>
				</li>
			</ul>
			<div class="nav">
				<a href="#">1</a>
				<a href="#">2</a>
				<a href="#">3</a>
				<a href="#">4</a>
			</div>
		</div>
	</div>
	<!-- End Slider -->