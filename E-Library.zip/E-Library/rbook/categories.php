
			<div class="products">
				<h3>Featured Library books Books</h3> <div id="login-details"> 

<form action="" method="post">  <input type="text" name="search" autofocus placeholder="Search by book or author...">   </form>
  </div>

<ul>  
<?php
$con=mysql_connect('localhost', 'root', '');
$db=mysql_select_db('ebook');
if(isset($_POST['search'])){   
$search=$_POST['search'];
$query=mysql_query("SELECT * FROM books WHERE author like '%{$search}%' || name like '%{$search}%'");
if (mysql_num_rows($query) > 0) {
  while ($row = mysql_fetch_array($query)) { ?>
	<li>
						<div class="product">
						<a href="#" class="info">
								<span class="holder">
									<img src="css/images/<?php echo $row['pic'];?>" alt="" />
									<span class="book-name"><?php echo $row['name'];?></span>
									<span class="author">by <?php echo $row['author'];?></span>
									<span class="description"><?php echo $row['description'];?></span>
								</span>
						
							<a href="buy.php?id=<?php echo $row['id'];?>&type=buy" class="buy-btn">Buy <span class="price"><span class="low">$</span><?php echo $row['price'];?><span class="high">00</span></span></a><br>

							<a href="rent.php?id=<?php echo $row['id'];?>&type=rent" class="rent-btn">Rent <span class="price"><span class="low">$</span><?php echo $row['rent'];?><span class="high">99</span></span>
							</a>
						</div>
					</a>
					</li>
 
 <?php }
}else{
    echo "No book or author called $search was found!";
  }}else{
$query=mysql_query("SELECT * FROM books");
  while ($row = mysql_fetch_array($query)) { ?>
               <li>
						<div class="product">
						<a href="#" class="info">
								<span class="holder">
									<img src="css/images/<?php echo $row['pic'];?>" alt="" />
									<span class="book-name"><?php echo $row['name'];?></span>
									<span class="author">by <?php echo $row['author'];?></span>
									<span class="description"><?php echo $row['description'];?></span>
								</span>
						
							<a href="buy.php?id=<?php echo $row['id'];?>&type=buy" class="buy-btn">Buy <span class="price"><span class="low">$</span><?php echo $row['price'];?><span class="high">00</span></span></a><br>

							<a href="rent.php?id=<?php echo $row['id'];?>&type=rent" class="rent-btn">Rent <span class="price"><span class="low">$</span><?php echo $row['rent'];?><span class="high">99</span></span>
							</a>
						</div>
					</a>
					</li>
 <?php } }


mysql_close();

?>





				</ul>
			</div>