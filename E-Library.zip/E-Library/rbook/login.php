<?php include("header.php");?>

<?php
 $id = $_GET['id'];
 $type = $_GET['type'];
include ("database/db.php"); 
  session_start();
   if (isset($_POST['password']) && isset($_POST['username'])){
    if (isset($_POST['password'])){
     $username = stripslashes($_REQUEST['username']); 
    $username = mysqli_real_escape_string($con,$username); 
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con,$password);
   $query = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
        if($rows==1){
$query = "SELECT * FROM users WHERE  username='$username' AND password='$password'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
if($rows==1){
       $_SESSION['username'] = $username;
   if ($id == '0') {
       $URL="bought.php";
   }elseif($type == 'rent'){
        $URL="rent.php?id=$id&type=$type";
   }else{
    $URL="buy.php?id=$id&type=$type";
   }
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
 }else{
    $fmsg ="Login failed! Wrong password. ";

 }
  }else
       {
         $fmsg ="Login failed! username does not exist.";
        }

       
    }
    else
    {
        $smsg ="<b>Customer authentication window.</b>";
    }}
?>
<div id="main" class="shell">

     <div class="login">
        <h1>Login Here</h1>
<?php if(isset($smsg)){ ?><br><div class="success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>  
<?php if(isset($fmsg)){ ?><br><div class="danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>

        <form action="" method="post">
            <br>
            <input type="text" name="username" required placeholder="Enter Username">
             <br>
            <input type="password" name="password" placeholder="Enter Password" required>
            <input type="submit" value="Login"><br>
             <?php $id = $_GET['id']; ?>
            <a href="forgot_password.php?id=<?php echo $id; ?>&type=<?php echo $type; ?>">Lost your password?</a>  
           
            <a href="signup.php?id=<?php echo $id; ?>&type=<?php echo $type; ?>">Don't have an account?</a>

        </form>
        
</div>
            
        
    
</div>

<?php include("footer.php");?>
 