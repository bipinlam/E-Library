<?php include("header.php");?>
<div id="main" class="shell">
  <?php include("sidebar.php");?>
  <div id="content">
    <div class="products">
    	<h3>About E-BOOK online library</h3>
<p style="font-size: 16px; text-align: center;">Highly optimized for readers. <br/><br/>We provide book rent at minimum price and 1 special book for premium membership where they will receive at low price. <br/><br/><b>We believe"knowledge is power </b> </p>
  </div>
    </div>  <div class="cl">&nbsp;</div>
  
</div>
  <div class="cl">&nbsp;</div>

<?php include("footer.php");?>
