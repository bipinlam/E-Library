<?php
   session_start();
   $id = $_GET['id'];
   $type = $_GET['type'];
   if($_SESSION['username']){ 
   }
   else{
 // Print '<script>alert("You need to be logged in first!");</script>';
           $URL="login.php?id=$id&type=$type";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
   }
   $username = $_SESSION['username']; 

   ?>
<?php
 $id = $_GET['id'];
  include ("database/db.php"); 
   
    if (isset($_POST['id']) && isset($_POST['credit_card'])){
    if (isset($_POST['id'])){
    $id = stripslashes($_REQUEST['id']);
    $id = mysqli_real_escape_string($con,$id);
    $credit_card = stripslashes($_REQUEST['credit_card']); 
    $credit_card = mysqli_real_escape_string($con,$credit_card); 
   	  
  $query = "UPDATE rent SET credit_card = '$credit_card' WHERE id='$id'";
     $result = mysqli_query($con,$query);
      if($result){
         Print '<script>alert("Your book rent request has been approved! Congratulations!");</script>';
         $URL="rented.php";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
}else{
           $fmsg ="Failed to rent book!";
        }  }}?>
          


<?php include("header1.php");?>
<div id="main" class="shell">
	<?php include("sidebar.php");?>
	
		<div id="content">
		<h3>Make Payments</h3>		
	
		
		<?php $result = mysqli_query($con,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
      while($row = mysqli_fetch_array($result)) {
$users_id = $row['id'];
     }  ?>

<div>
<form action="" method="post">
  <input type="hidden" name="books_id" value="<?php echo $row['id'];?>">
  <link rel="stylesheet" type="text/css" href="js/jquery.datetimepicker.css"/>

<?php 
$result = mysqli_query($con,"SELECT * FROM rent WHERE users_id='$users_id' ORDER BY id DESC LIMIT 1");
      while($row = mysqli_fetch_array($result)) {
        $price = 3*$row['period'];
            ?>
    <input type="text" name="end_date" value="From <?php echo $row['created'];?> to <?php echo $row['end_date'];?>" readonly/>
    <input type="hidden" name="id" value="<?php echo $row['id'];?>">
    <input type="text" name="period" value="Renting period:  <?php echo $row['period'];?> Days" readonly>
    <input type="text" name="price" value="To pay $<?php echo $price;?>.00 as renting fee" readonly>


    <input type="text" name="credit_card" placeholder="Enter valid credit card number" required >


<?php } $result = mysqli_query($con,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
      while($row = mysqli_fetch_array($result)) {?>
<input type="hidden" name="users_id" value="<?php echo $row['id'];?>">
<input type="submit" class="social facebook" value="Complete">
</form>
	
</div>
  		</div>
  		 <?php } mysqli_close($con); ?>
			<div class="cl">&nbsp;</div>
	
</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>
  <script src="js/jquery.js"></script>
        <script src="js/jquery.datetimepicker.full.js"></script>

        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';

                jQuery('#filter-date, #search-from-date, #search-to-date').datetimepicker();
            });
        </script>
