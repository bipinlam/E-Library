<?php
error_reporting(1);
   session_start();
   $id = $_GET['id'];
   $type = $_GET['type'];
   if($_SESSION['username']){ 
   }
   else{
 // Print '<script>alert("You need to be logged in first!");</script>';
           $URL="login.php?id=$id&type=$type";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
   }
   $username = $_SESSION['username']; 

   ?>
<?php
 $id = $_GET['id'];
  include ("database/db.php"); 
   
    if (isset($_POST['users_id']) && isset($_POST['books_id'])){
    if (isset($_POST['users_id'])){
    $users_id = stripslashes($_REQUEST['users_id']);
    $users_id = mysqli_real_escape_string($con,$users_id);
    $books_id = stripslashes($_REQUEST['books_id']); 
    $books_id = mysqli_real_escape_string($con,$books_id); 
    $end_date = stripslashes($_REQUEST['end_date']); 
    $end_date = mysqli_real_escape_string($con,$end_date); 
    $credit_card = stripslashes($_REQUEST['credit_card']); 
    $credit_card = mysqli_real_escape_string($con,$credit_card); 
   // $created = date('d-m-y');
	  
  $query = "INSERT INTO rent (users_id, books_id, created, end_date, credit_card) VALUES('$users_id', '$books_id', now(), '$end_date', '$credit_card')";
     $result = mysqli_query($con,$query);
      $query = "UPDATE rent SET period = DATEDIFF(end_date, created)";
     $result = mysqli_query($con,$query);
      if($result){
         $URL="confirm-rent.php?id=$id&type=rent";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
}else{
           $fmsg ="Failed to rent book!";
        }  }}?>
          


<?php include("header1.php");?>
<div id="main" class="shell">
	<?php include("sidebar.php");?>
	<?php $result = mysqli_query($con,"SELECT * FROM books WHERE id='$id'");
      while($row = mysqli_fetch_array($result)) {?>
		<div id="content">
		<h3>Book rent module</h3>		
	<span class="holder">
		<img src="css/images/<?php echo $row['pic'];?>" alt="" style="min-height: 300px;"/><br>
		<h4><?php echo $row['name'];?> <br>
		by <?php echo $row['author'];?></h4><br>
		<span class="description"><?php echo $row['description'];?></span><br>
		
	</span>
<div>
<form action="" method="post">
  <link rel="stylesheet" type="text/css" href="js/jquery.datetimepicker.css"/>
   <input type="text" name="end_date" id="filter-date" placeholder="Date to return the book" required/>

    
    <input type="hidden" name="credit_card" placeholder="Credit card number" required="" >
<input type="hidden" name="books_id" value="<?php echo $row['id'];?>">
<?php } $result = mysqli_query($con,"SELECT * FROM users WHERE username='{$_SESSION['username']}'");
      while($row = mysqli_fetch_array($result)) {?>
<input type="hidden" name="users_id" value="<?php echo $row['id'];?>">
<input type="submit" class="social facebook" value="Proceed">
</form>
	
</div>
  		</div>
  		 <?php } mysqli_close($con); ?>
			<div class="cl">&nbsp;</div>
	
</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>
  <script src="js/jquery.js"></script>
        <script src="js/jquery.datetimepicker.full.js"></script>

        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';

                jQuery('#filter-date, #search-from-date, #search-to-date').datetimepicker();
            });
        </script>
