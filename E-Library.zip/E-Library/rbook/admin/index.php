
<?php include("header.php");?>

<div id="main" class="shell">
	<?php include("sidebar.php");?>
		<div id="content">	
		<h3>Books library</h3>
		<a href="add_book.php"><button class="read twitter">Add book</button></a>	
			<table width="100%">
				<tr>
					<th>Book number</th>
					<th>Book name</th>
					<th>Author</th>
					<th>Selling price</th>
					<th>Action</th>
				</tr>
		<?php $result = mysqli_query($con,"SELECT * FROM books");
      while($row = mysqli_fetch_array($result)) {?>
				<tr>
					<td><?php echo $row['id'];?></td>
					<td><?php echo $row['name'];?></td>
					<td><?php echo $row['author'];?></td>
					<td>$<?php echo $row['price'];?>.00</td>
					<td><a href="delbook.php?id=<?php echo $row['id'];?>"> <button>Delete</button></a></td>
				</tr>
				<?php } mysqli_close($con); ?>
			</table>
	 
  		</div>
			<div class="cl">&nbsp;</div>
	</div>
	<div class="cl">&nbsp;</div>

<?php include("footer.php");?>

