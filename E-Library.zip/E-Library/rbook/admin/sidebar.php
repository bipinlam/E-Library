<!-- Sidebar -->
		<div id="sidebar">
			<ul class="categories">
				<li>
					<h4>My menu</h4>
					<ul>
						<li><a href="#">Science fiction</a></li>
						<li><a href="#">Satire</a></li>
						<li><a href="#">Drama</a></li>
						<li><a href="#">Action and Adventure</a></li>
						<li><a href="#">Romance</a></li>
						<li><a href="#">Mystery</a></li>
						<li><a href="#">Horror</a></li>
					</ul>
				</li>
				</ul>
		</div>
		<!-- End Sidebar -->