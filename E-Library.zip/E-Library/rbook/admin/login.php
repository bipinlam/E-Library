

<?php
 include ("database/db.php"); 
  session_start();
   if (isset($_POST['password']) && isset($_POST['email'])){
    if (isset($_POST['password'])){
     $email = stripslashes($_REQUEST['email']); 
    $email = mysqli_real_escape_string($con,$email); 
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con,$password);
   $query = "SELECT * FROM admin WHERE email='$email'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
        if($rows==1){
$query = "SELECT * FROM admin WHERE  email='$email' AND password='$password'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
if($rows==1){
       $_SESSION['email'] = $email;
   
    $URL="index.php";
  echo "<script type='text/javascript'>document.location.href='{$URL}';</script>";
 }else{
    $fmsg ="Login failed! Wrong password. ";

 }
  }else
       {
         $fmsg ="Login failed! email does not exist.";
        }

       
    }
    else
    {
        $smsg ="<b>Customer authentication window.</b>";
    }}
?>
<!DOCTYPE html>

<html>
<head>
  <title>E-BOOK Online Library</title>
  <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
  <link rel="shortcut icon" href="css/images/favicon.ico" />
  <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
  <script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
  <script type="text/javascript" src="js/jquery.jcarousel.min.js"></script>
  <link rel="stylesheet" type="text/css" href="stylelogin.css">
  <link rel="stylesheet" type="text/css" href="signup.css">

  <!--[if IE 6]>
    <script type="text/javascript" src="js/png-fix.js"></script>
  <![endif]-->
  <script type="text/javascript" src="js/functions.js"></script>
</head>
<body>
  <!-- Header -->
  <div id="header" class="shell">

    <div id="logo"><h1><a href="#">Aussiebook</a></h1><span><a href="#">Trusted online e-book service</a></span></div>
    <!-- Navigation -->
    <div id="navigation">
      
    </div>
    <!-- End Navigation -->
    <div class="cl">&nbsp;</div>
    <!-- Login-details -->
    <div id="login-details">
      <p>Welcome, <a href="#" id="user">Guest</a> .</p><p><a href="#" class="cart" ><img src="css/images/cart-icon.png" alt=""></a> 
      
    </div>
    <!-- End Login-details -->
  </div>
  <!-- End Header -->
<div id="main" class="shell">

     <div class="login">
        <h1>Login Here</h1><hr>
<?php if(isset($smsg)){ ?><br><div class="success" role="alert"> <?php echo $smsg; ?> </div><?php } ?>  
<?php if(isset($fmsg)){ ?><br><div class="danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>

        <form action="" method="post">
            <br>
            <input type="email" name="email" required placeholder="Enter email">
             <br>
            <input type="password" name="password" placeholder="Enter Password" required>
            <input type="submit" value="Login"><br>
             
        </form>
        
</div>
            
        
    
</div>

</body>
</html>>

 