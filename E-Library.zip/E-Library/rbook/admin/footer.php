
<?php
  include ("database/db.php"); 
    if (isset($_POST['username']) && isset($_POST['email'])){
    if (isset($_POST['username'])){
    $username = stripslashes($_REQUEST['username']);
    $username = mysqli_real_escape_string($con,$username);
    $email = stripslashes($_REQUEST['email']); 
    $email = mysqli_real_escape_string($con,$email); 
   

 $query = "SELECT * FROM Newsletter WHERE email='$email'";
    $result = mysqli_query($con,$query) or die(mysqli_error());
    $rows = mysqli_num_rows($result);
        if($rows!=0){
           // $fmsg ="Email address already registered!";
        	Print '<script>alert("Email address already registered!");</script>';
           }
           else{
            $query = "INSERT INTO Newsletter (username, email) VALUES('$username', '$email')";
     $result = mysqli_query($con,$query);
      if($result){
      	Print '<script>alert("You have successfully registered for our newsletter to be sent to your email!");</script>';
} }}}?>
          

	<div id="footer" class="shell">
		<div class="top">
			<div class="cnt">
				<div class="col about">
					<h4>About ebook online library</h4>
					<p>Highly optimized for readers. <br />We provide book rent at minimum price and 1 special book for premium membership where they will receive at low price. <br />we believe"knowledge is power  </p>
				</div>
				<div class="col store">
					<h4>Quick links</h4>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li><a href="contacts.php">Contact us</a></li>
						<li><a href="login.php">Log In</a></li>
						<li><a href="login.php">Account</a></li>
					
					</ul>
				</div>
				<div class="col" id="newsletter">
					<h4>Newsletter</h4>
					<p>Get update with our news. </p>
					<form action="" method="post">
						<input type="text" class="field" name="username" value="Your Name" title="Your Name" required="" />
						<input type="email" class="field" name="email" value="Email" title="Email" required="" />
						<div class="form-buttons"><input type="submit" value="Submit" class="submit-btn" /></div>
					</form>
				</div>
				<div class="cl">&nbsp;</div>
				<div class="copy">
					<p>&copy; <a href="#">ebook.com</a>. Design by <a href="#">bipin-e-book limited</a></p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>>
