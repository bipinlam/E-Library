<?php
 include ("database/db.php"); 
 $id = $_GET['id'];
         $query = "DELETE FROM books WHERE id='$id'";
        $result = mysqli_query($con,$query);
        if($result){
        Print '<script>window.location.assign("index.php");</script>'; 
        }
   
?>