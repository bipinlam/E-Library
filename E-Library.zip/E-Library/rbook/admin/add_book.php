<?php
error_reporting(1);
 include ("database/db.php");
 extract($_POST);
$target_dir = "../css/images/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$videoFileType = pathinfo($target_file,PATHINFO_EXTENSION);
$target_dir = "../css/images/";
$target_file = $target_dir . basename($_FILES["fileToUpload1"]["name"]);
$videoFileType = pathinfo($target_file,PATHINFO_EXTENSION);
if($upd){

if($videoFileType != "JPG" && $videoFileType != "jpg" && $videoFileType != "png" && $videoFileType != "JPEG" && $videoFileType != "gif" && $videoFileType != "BMP" && $videoFileType != "bmp" && $videoFileType != "" && $videoFileType != "pdf"){
     $fmsg ="Bad image type!";
       
} else{
 if (isset($_POST['price']) && isset($_POST['author'])){
    if (isset($_REQUEST['price'])){
    $price = stripslashes($_REQUEST['price']); 
    $price = mysqli_real_escape_string($con,$price); 
    $rent = stripslashes($_REQUEST['rent']); 
    $rent = mysqli_real_escape_string($con,$rent); 
    $author = stripslashes($_REQUEST['author']);
    $author = mysqli_real_escape_string($con,$author);
    $description = stripslashes($_REQUEST['description']);
    $description = mysqli_real_escape_string($con,$description);
    $name = stripslashes($_REQUEST['name']);
    $name = mysqli_real_escape_string($con,$name);
    $file_path= stripslashes($_FILES['fileToUpload']['name']);
    $file_path1= stripslashes($_FILES['fileToUpload1']['name']);
   
$query = "INSERT INTO books (price, author, description, pic, date, rent, name, book) VALUES ('$price', '$author', '$description', '$file_path', now(),'$rent','$name', '$file_path1')";
        $result = mysqli_query($con,$query);
        move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir.basename($_FILES['fileToUpload']['name']));
        move_uploaded_file($_FILES["fileToUpload1"]["tmp_name"], $target_dir.basename($_FILES['fileToUpload1']['name']));
       
        if($result){
          Print '<script>alert("Book bas been added successfully");</script>'; 
           }
    else{
        Print '<script>alert("Error! Failed to save book!");</script>'; 
        }


}
}}
}
?>
<?php include("header.php");?>


          

           
    
  


<div id="main" class="shell">
  <?php include("sidebar.php");?>
    <div id="content">  
    <h3>Add book to library</h3>
                          <form method="post" action="" enctype="multipart/form-data">
 

<input type="text" name="name" placeholder="Book name">
<input type="text" name="author" placeholder="Book author">
<input type="text" name="price" placeholder="Selling price">
<input type="text" name="rent" placeholder="Renting price/day">      
       <input type="text" name="description" placeholder="Brief book description">
      <h4>Attach a picture</h4>
            <input type="file" name="fileToUpload">
      <h4>Attach the book file</h4>
      <input type="file" name="fileToUpload1"><br>
      <input type="submit" value="Save book" name="upd">
                            </form>
   
      </div>
      <div class="cl">&nbsp;</div>
  </div>
  <div class="cl">&nbsp;</div>

<?php include("footer.php");?>