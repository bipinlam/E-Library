<?php
   session_start(); ?>
<?php include("database/db.php");?>
<!DOCTYPE html>

<html>
<head>
	<title>E-BOOK Online Library</title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<script type="text/javascript" src="js/jquery-1.6.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.jcarousel.min.js"></script>
	<link rel="stylesheet" type="text/css" href="stylelogin.css">
	<link rel="stylesheet" type="text/css" href="signup.css">

	<!--[if IE 6]>
		<script type="text/javascript" src="js/png-fix.js"></script>
	<![endif]-->
	<script type="text/javascript" src="js/functions.js"></script>
</head>
<body>
	<!-- Header -->
	<div id="header" class="shell">

		<div id="logo"><h1><a href="#">Aussiebook</a></h1><span><a href="#">Trusted online e-book service</a></span></div>
		<!-- Navigation -->
		<div id="navigation">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="bought.php">History of purchase</a></li>
				<li><a href="about.php">About Us</a></li>
				<li><a href="contacts.php">Contacts</a></li>
				<?php error_reporting(1);
 				if($_SESSION['username']){ ?>
				<li><a href="logout.php">Logout</a></li>
				<?php } else{ ?>
				<li><a href="login.php?id=0&type=0">Login</a></li>
				<?php } ?>
			</ul>
		</div>
		<!-- End Navigation -->
		<div class="cl">&nbsp;</div>
		<!-- Login-details -->
		<div id="login-details">
			<?php 
error_reporting(1);
 if($_SESSION['username']){ ?>
<p>Welcome, <a href="#" id="user"><?php echo $_SESSION['username']; ?></a> .</p><p><a href="#" class="cart" ><img src="css/images/cart-icon.png" alt=""></a> 
 <?php   }
   else{ ?>
<p>Welcome, <a href="#" id="user">Guest</a> .</p><p><a href="#" class="cart" ><img src="css/images/cart-icon.png" alt=""></a> 
		<?php } ?>
			
			
		</div>
		<!-- End Login-details -->
	</div>
	<!-- End Header -->