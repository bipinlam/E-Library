-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2018 at 03:49 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ebook`
--
CREATE DATABASE IF NOT EXISTS `ebook` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ebook`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'kakai', 'kakaielvis@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `price` varchar(1000) NOT NULL,
  `description` varchar(50000) NOT NULL,
  `date` date NOT NULL,
  `name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `rent` int(100) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `book` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `price`, `description`, `date`, `name`, `author`, `rent`, `pic`, `book`) VALUES
(8, '230', 'qwertyui wertyu', '2018-10-02', 'Two love birds', 'Kakai elvis', 23, 'best-price.png', 'think-big.pdf'),
(9, '102', ' The greatest thing in life is to keep your mind young.', '2018-10-02', 'Think and grow rich', 'Donald trump', 34, 'best-sellers-directions.png', 'ARTSON SYSTEMS COOPORATION REPORT.pdf'),
(10, '45', 'This is book is for the poor society to up their game', '2018-10-02', 'romeo and juliet', 'william shakespear', 34, 'gatundu.jpg', 'MIYOGI.pdf'),
(11, '23', ' The greatest thing in life is to keep your mind young.', '2018-10-02', 'The higher power', 'Ramah Rando', 5, 'mother and child.jpg', 'EAFYA.pdf'),
(12, '129', 'and am sure of this The greatest thing in life is to keep your mind young.', '2018-10-02', 'What kenyan businessmen never tell you', 'Antony Njagi', 1, 'image01.jpg', 'romeo-and-juliet.pdf'),
(13, '123', ' The greatest thing in life is to keep your mind young. The greatest thing in life is to keep your mind young.', '2018-10-02', 'Be still', 'Faith Wanjiru', 2, 'image02.jpg', 'ARTSON SYSTEMS COOPORATION REPORT.pdf'),
(14, '32', ' The greatest thing in life is to keep your mind young.', '2018-10-02', 'Once a blue moon', 'Profeso Akoto', 1, 'books.png', 'EAFYA.pdf'),
(15, '32', ' The greatest thing in life is to keep your mind young.', '2018-10-02', 'Kifo Kisimani', 'Kithaka Wa nMberia', 1, 'image04.jpg', 'ARTSON SYSTEMS COOPORATION REPORT.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `buy`
--

CREATE TABLE IF NOT EXISTS `buy` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `users_id` int(100) NOT NULL,
  `books_id` int(100) NOT NULL,
  `created` date NOT NULL,
  `end_date` date NOT NULL,
  `credit_card` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `buy`
--

INSERT INTO `buy` (`id`, `users_id`, `books_id`, `created`, `end_date`, `credit_card`) VALUES
(1, 5, 1, '2018-10-01', '2018-10-06', 0),
(2, 5, 1, '2018-10-01', '0000-00-00', 0),
(3, 5, 1, '2018-10-01', '0000-00-00', 0),
(4, 5, 1, '2018-10-01', '0000-00-00', 345678),
(5, 3, 1, '2018-10-01', '0000-00-00', 1234567),
(6, 3, 1, '2018-10-01', '0000-00-00', 2345678),
(7, 3, 2, '2018-10-01', '0000-00-00', 345678),
(8, 7, 2, '2018-10-01', '0000-00-00', 2345),
(9, 7, 11, '2018-10-02', '0000-00-00', 23456),
(10, 8, 9, '2018-10-03', '0000-00-00', 0),
(11, 8, 9, '2018-10-03', '0000-00-00', 12345678),
(12, 8, 8, '2018-10-03', '0000-00-00', 456876),
(13, 8, 13, '2018-10-03', '0000-00-00', 78665434);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`id`, `username`, `email`) VALUES
(1, 'kaka', 'kakaielvis@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `rent`
--

CREATE TABLE IF NOT EXISTS `rent` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `users_id` int(100) NOT NULL,
  `books_id` int(100) NOT NULL,
  `created` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `credit_card` int(100) NOT NULL,
  `period` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Dumping data for table `rent`
--

INSERT INTO `rent` (`id`, `users_id`, `books_id`, `created`, `end_date`, `credit_card`, `period`) VALUES
(34, 7, 2, '2002-10-18', '2018-10-05', 0, 5831),
(35, 7, 2, '2018-10-02', '2018-10-06', 0, 4),
(36, 7, 2, '2018-10-02', '2018-10-05', 0, 3),
(37, 7, 2, '2018-10-02', '2018-10-06', 0, 4),
(38, 7, 2, '2018-10-02', '2018-10-05', 0, 3),
(39, 7, 2, '2018-10-02', '2018-10-09', 234567, 7),
(40, 7, 11, '2018-10-02', '2018-10-20', 3456789, 18),
(41, 7, 9, '2018-10-02', '2018-10-06', 1234567, 4),
(42, 7, 12, '2018-10-02', '2018-10-06', 345678, 4),
(43, 7, 8, '2018-10-02', '2018-10-13', 12345678, 11),
(44, 7, 10, '2018-10-03', '2018-10-06', 123456, 3),
(45, 8, 11, '2018-10-03', '2018-10-13', 19084563, 10),
(46, 8, 9, '2018-10-03', '2018-10-25', 0, 22),
(47, 8, 14, '2018-10-03', '2018-10-06', 450983, 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(7, '0711521811', 'purity@gmail.com', '123456');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
